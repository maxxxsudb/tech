(function (factory) {
  if (typeof define === "function") define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
})(function () {
  "use strict";
  function expression(target) {
    if (!target) return "";
    for (const key of ["expr", "query", "rawSql"]) if (typeof (target || {})[key] === "string") return target[key];
    return JSON.stringify(target || {}, null, 2);
  }
  function targetId(target, index) { return String(target.refId || "__target_" + index); }
  function diffLines(before, after) {
    const a = String(before || "").split("\n");
    const b = String(after || "").split("\n");
    if (a.length * b.length > 160000) return a.map((text) => ({ type: "remove", text })).concat(b.map((text) => ({ type: "add", text })));
    const table = Array.from({ length: a.length + 1 }, () => new Uint32Array(b.length + 1));
    for (let i = a.length - 1; i >= 0; i--) for (let j = b.length - 1; j >= 0; j--) table[i][j] = a[i] === b[j] ? table[i + 1][j + 1] + 1 : Math.max(table[i + 1][j], table[i][j + 1]);
    const result = [];
    let i = 0, j = 0;
    while (i < a.length || j < b.length) {
      if (i < a.length && j < b.length && a[i] === b[j]) { result.push({ type: "equal", text: a[i++] }); j++; }
      else if (i < a.length && (j >= b.length || table[i + 1][j] >= table[i][j + 1])) result.push({ type: "remove", text: a[i++] });
      else result.push({ type: "add", text: b[j++] });
    }
    return result;
  }
  function mergeSelectedTargets(current, proposed, selected) {
    const ids = new Set(selected);
    const result = current.slice();
    proposed.forEach((target, index) => {
      if (!ids.has(targetId(target, index))) return;
      const found = target.refId ? result.findIndex((item) => item.refId === target.refId) : index < result.length ? index : -1;
      const merged = Object.assign({}, found >= 0 ? result[found] : {}, target);
      if (found >= 0) result[found] = merged;
      else result.push(merged);
    });
    return result;
  }
  function diffTargetsList(previous, current) {
    previous = previous || [];
    current = current || [];
    const ids = new Set(previous.map(targetId).concat(current.map(targetId)));
    return Array.from(ids).flatMap(refId => {
      const before = previous.find((target, index) => targetId(target, index) === refId);
      const after = current.find((target, index) => targetId(target, index) === refId);
      if (JSON.stringify(before) === JSON.stringify(after)) return [];
      const changedExpression = expression(before) !== expression(after);
      return [{ refId, before: changedExpression ? expression(before) : JSON.stringify(before || {}), after: changedExpression ? expression(after) : JSON.stringify(after || {}) }];
    });
  }
  function selectedMergedTargets(current, proposed, selected) {
    const ids = new Set(selected);
    return proposed.flatMap((target, index) => {
      if (!ids.has(targetId(target, index))) return [];
      const before = target.refId ? current.find(item => item.refId === target.refId) : current[index];
      return [Object.assign({}, before, target)];
    });
  }
  function sqlTokens(text) {
    const tokens = [];
    for (let i = 0; i < text.length;) {
      if (/\s/.test(text[i])) { i++; continue; }
      if (text.slice(i, i + 2) === '--') { i = text.indexOf('\n', i); if (i < 0) break; continue; }
      if (text.slice(i, i + 2) === '/*') {
        let depth = 1; i += 2;
        while (i < text.length && depth) { if (text.slice(i, i + 2) === '/*') { depth++; i += 2; } else if (text.slice(i, i + 2) === '*/') { depth--; i += 2; } else i++; }
        if (depth) throw new Error('Незакрытый комментарий SQL');
        continue;
      }
      const dollar = /^\$(?:[a-zA-Z_][a-zA-Z_0-9]*)?\$/.exec(text.slice(i));
      if (dollar) { const end = text.indexOf(dollar[0], i + dollar[0].length); if (end < 0) throw new Error('Незакрытая dollar-строка SQL'); i = end + dollar[0].length; tokens.push({ value: '<string>' }); continue; }
      if (text[i] === "'" || text[i] === '"') {
        const quote = text[i++]; let value = '', closed = false;
        while (i < text.length) { if (text[i] === '\\') throw new Error('Для SQL-инструмента используйте SQL-экранирование кавычек без backslash'); if (text[i] === quote) { if (text[i + 1] === quote) { value += quote; i += 2; } else { i++; closed = true; break; } } else value += text[i++]; }
        if (!closed) throw new Error('Незакрытая строка или идентификатор SQL');
        tokens.push({ value: quote === '"' ? value : '<string>', quoted: quote === '"' }); continue;
      }
      const word = /^[\p{L}_][\p{L}\p{N}_$]*/u.exec(text.slice(i));
      if (word) { tokens.push({ value: word[0].toLowerCase() }); i += word[0].length; }
      else tokens.push({ value: text[i++] });
    }
    return tokens;
  }

  function boundedSql(rawSql, rowLimit) {
    if (typeof rawSql !== 'string' || !rawSql.trim() || rawSql.length > 20000) throw new Error('SQL должен содержать от 1 до 20000 символов');
    const text = rawSql.trim().replace(/;\s*$/, '');
    const tokens = sqlTokens(text);
    if (!['select', 'with'].includes(tokens[0]?.value) || tokens[0].quoted) throw new Error('SQL-инструмент выполняет только SELECT или читающий WITH');
    const forbidden = new Set(['insert', 'update', 'delete', 'merge', 'into', 'copy', 'call', 'do', 'create', 'alter', 'drop', 'truncate', 'grant', 'revoke', 'vacuum', 'analyze', 'explain', 'set', 'reset', 'lock', 'listen', 'notify', 'unlisten', 'execute', 'prepare', 'deallocate', 'refresh', 'recursive', 'for']);
    const functions = new Set(('count sum avg min max abs round floor ceil ceiling trunc sqrt power mod coalesce nullif greatest least cast extract date_part date_trunc date_bin to_timestamp to_char to_date now current_timestamp timezone age make_interval lower upper length char_length substring substr trim btrim ltrim rtrim replace concat concat_ws split_part strpos position regexp_replace regexp_match regexp_matches bool_and bool_or every array_agg string_agg json_agg jsonb_agg json_build_object jsonb_build_object json_extract_path_text jsonb_extract_path_text json_array_length jsonb_array_length unnest generate_series percentile_cont percentile_disc mode stddev stddev_pop stddev_samp variance var_pop var_samp row_number rank dense_rank lag lead first_value last_value nth_value ntile numeric decimal varchar char text date timestamp timestamptz time interval smallint integer bigint int float float4 float8 boolean __timefrom __timeto __unixepochfrom __unixepochto __timefilter __timegroup __timegroupalias __time __timeepoch __unixepochfilter __unixepochgroup __unixepochgroupalias').split(' '));
    const syntax = new Set(['as', 'in', 'not', 'over', 'filter', 'within', 'group', 'values', 'distinct', 'select', 'from', 'where', 'and', 'or', 'on', 'having', 'exists', 'any', 'all', 'when', 'then', 'else', 'join', 'lateral', 'using', 'union', 'intersect', 'except']);
    for (let i = 0; i < tokens.length; i++) {
      const { value, quoted } = tokens[i];
      if (value === ';' || (!quoted && forbidden.has(value))) throw new Error('SQL-инструмент отклонил команду: ' + value);
      if (quoted && tokens[i + 1]?.value === '(') throw new Error('Quoted function требует ручной проверки: ' + value);
      if (tokens[i + 1]?.value === '(' && /^(?:pg_(?!catalog$)|dblink|lo_|set_config$|nextval$|setval$)/.test(value)) throw new Error('Функция SQL недоступна в инструменте: ' + value);
      if (tokens[i + 1]?.value === '(' && (quoted || /^[\p{L}_]/u.test(value)) && (quoted || !syntax.has(value))) {
        if (!functions.has(value) || (tokens[i - 1]?.value === '.' && tokens[i - 2]?.value !== 'pg_catalog')) throw new Error('Функция SQL требует ручной проверки: ' + value);
      }
    }
    const limit = Math.max(1, Math.min(500, Math.floor(Number(rowLimit) || 100)));
    return { rawSql: `SELECT * FROM (\n${text}\n) AS "__tech_ai_result" LIMIT ${limit + 1}`, rowLimit: limit };
  }

  function postgresSchemaQuery(args) {
    const literal = value => "'" + String(value).replace(/'/g, "''") + "'";
    const action = args.action;
    if (action === 'tables') {
      const match = String(args.match || '').slice(0, 100);
      return `SELECT table_schema, table_name, table_type FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema') AND position(lower(${literal(match)}) in lower(table_schema || '.' || table_name)) > 0 ORDER BY table_schema, table_name LIMIT 101`;
    }
    if (!['columns', 'foreign_keys', 'indexes'].includes(action)) throw new Error('PostgreSQL schema: используйте tables, columns, foreign_keys или indexes');
    if (![args.schema, args.table].every(value => typeof value === 'string' && value.length > 0 && value.length <= 128 && !value.includes('\0'))) throw new Error('Укажите schema и table из результата tables');
    const schema = literal(args.schema), table = literal(args.table);
    if (action === 'columns') return `SELECT column_name, data_type, udt_name, is_nullable, numeric_precision, numeric_scale, datetime_precision, ordinal_position FROM information_schema.columns WHERE table_schema=${schema} AND table_name=${table} ORDER BY ordinal_position LIMIT 101`;
    if (action === 'indexes') return `SELECT indexname, indexdef FROM pg_catalog.pg_indexes WHERE schemaname=${schema} AND tablename=${table} ORDER BY indexname LIMIT 101`;
    return `SELECT c.conname AS constraint_name, a.attname AS column_name, rn.nspname AS referenced_schema, rt.relname AS referenced_table, ra.attname AS referenced_column FROM pg_catalog.pg_constraint c JOIN pg_catalog.pg_class t ON t.oid=c.conrelid JOIN pg_catalog.pg_namespace n ON n.oid=t.relnamespace JOIN pg_catalog.pg_class rt ON rt.oid=c.confrelid JOIN pg_catalog.pg_namespace rn ON rn.oid=rt.relnamespace JOIN LATERAL generate_subscripts(c.conkey,1) AS pos(i) ON true JOIN pg_catalog.pg_attribute a ON a.attrelid=t.oid AND a.attnum=c.conkey[pos.i] JOIN pg_catalog.pg_attribute ra ON ra.attrelid=rt.oid AND ra.attnum=c.confkey[pos.i] WHERE c.contype='f' AND n.nspname=${schema} AND t.relname=${table} AND has_table_privilege(t.oid,'SELECT') ORDER BY c.conname,pos.i LIMIT 101`;
  }

  function sqlFeedback(results) {
    const error = Object.values(results || {}).map(result => result.error).find(Boolean);
    if (!error) return undefined;
    const state = /SQLSTATE[\s:(]+([0-9A-Z]{5})/i.exec(error)?.[1];
    const hint = { '42703': 'Прочитайте columns для реальной таблицы; исправьте имя или quoted identifier.', '42P01': 'Прочитайте tables; проверьте schema и search_path.', '42883': 'Проверьте типы columns и сигнатуру функции.', '42501': 'Недостаточно прав: не повторяйте запрос и не пытайтесь обойти ограничения.', '57014': 'Запрос отменён: сузьте период и уменьшите объём чтения.' }[state];
    return { sqlState: state, hint: hint || 'Исправьте SQL по фактической ошибке; не выдумывайте имена таблиц и колонок.' };
  }
  return { expression, targetId, diffLines, mergeSelectedTargets, diffTargetsList, selectedMergedTargets, boundedSql, postgresSchemaQuery, sqlFeedback };
});
