(function (factory) {
  if (typeof define === "function") define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
})(function () {
  "use strict";

  function ruleUid(pathname) {
    const match = /\/alerting\/grafana\/([^/]+)\/(?:view|edit)(?:\/|$)/.exec(pathname || "");
    if (!match) return undefined;
    try { return decodeURIComponent(match[1]); } catch (_) { return undefined; }
  }

  function normalizeRule(value) {
    const source = value.grafana_alert || value;
    return {
      uid: source.uid || value.uid,
      title: source.title || value.name || value.alert,
      folderUID: source.folderUID || source.namespace_uid,
      ruleGroup: source.ruleGroup || source.rule_group,
      condition: source.condition,
      for: value.for ?? source.for,
      keepFiringFor: source.keep_firing_for ?? source.keepFiringFor,
      missingSeriesEvalsToResolve: source.missingSeriesEvalsToResolve,
      notificationSettings: source.notification_settings,
      noDataState: source.noDataState || source.no_data_state,
      execErrState: source.execErrState || source.exec_err_state,
      isPaused: source.isPaused ?? source.is_paused,
      provenance: source.provenance,
      labels: value.labels || source.labels || {},
      annotations: value.annotations || source.annotations || {},
      state: value.state,
      health: value.health,
      lastError: value.lastError,
      lastEvaluation: value.lastEvaluation,
      data: Array.isArray(source.data) ? source.data.map(query => ({
        refId: query.refId, datasourceUid: query.datasourceUid,
        relativeTimeRange: query.relativeTimeRange, queryType: query.queryType, model: query.model,
      })) : [],
    };
  }

  function stateRules(response) {
    if (!response || response.status !== "success" || !response.data || !Array.isArray(response.data.groups)) throw new Error("Некорректный ответ состояния правил");
    return response.data.groups.flatMap(group => (group.rules || []).map(value => Object.assign(normalizeRule(value), { group: group.name, interval: group.interval })));
  }

  function alertRuleUid(value) {
    const labels = value.labels || {};
    if (labels.__alert_rule_uid__) return labels.__alert_rule_uid__;
    if (labels.__rule_uid__) return labels.__rule_uid__;
    try { return ruleUid(new URL(value.generatorURL, "http://grafana.invalid").pathname); } catch (_) { return undefined; }
  }

  function normalizeAlert(value) {
    return {
      ruleUid: alertRuleUid(value), fingerprint: value.fingerprint,
      labels: value.labels || {}, annotations: value.annotations || {},
      startsAt: value.startsAt, endsAt: value.endsAt, updatedAt: value.updatedAt,
      status: value.status && { state: value.status.state, silencedBy: value.status.silencedBy, inhibitedBy: value.status.inhibitedBy },
    };
  }

  function summarizeAlerts(alerts, now) {
    const groups = new Map();
    for (const alert of alerts) {
      const service = alert.labels.service || "не указан";
      const severity = alert.labels.severity || "не указана";
      const key = JSON.stringify([service, severity]);
      const group = groups.get(key) || { service, severity, instances: 0, suppressed: 0, oldestAt: undefined, ruleUids: [] };
      group.instances++;
      if (alert.status && alert.status.state === "suppressed") group.suppressed++;
      const start = Date.parse(alert.startsAt);
      if (Number.isFinite(start) && start > 0 && start <= now && (!group.oldestAt || start < Date.parse(group.oldestAt))) group.oldestAt = alert.startsAt;
      if (alert.ruleUid && !group.ruleUids.includes(alert.ruleUid)) group.ruleUids.push(alert.ruleUid);
      groups.set(key, group);
    }
    return { instances: alerts.length, groups: Array.from(groups.values()).sort((a, b) => b.instances - a.instances) };
  }

  function linkedPanel(rule) {
    const annotations = rule && rule.annotations || {};
    const id = Number(annotations.__panelId__ || annotations.panelId);
    return {
      dashboardUid: annotations.__dashboardUid__ || annotations.dashboardUid,
      panelId: Number.isInteger(id) && id > 0 ? id : undefined,
    };
  }

  async function readContext(request, options) {
    options = options || {};
    const now = options.now || Date.now(), uid = options.uid;
    const endpoints = [
      ["rules", "/api/v1/provisioning/alert-rules" + (uid ? "/" + encodeURIComponent(uid) : "")],
      ["states", "/api/prometheus/grafana/api/v1/rules"],
      ["instances", "/api/alertmanager/grafana/api/v2/alerts"],
    ];
    const readStatus = {}, results = {};
    await Promise.all(endpoints.map(async ([name, path]) => {
      try {
        const response = await request(path, { signal: options.signal, timeoutMs: 10000 });
        if (name === "rules") {
          if (uid ? !response || typeof response !== "object" || Array.isArray(response) || response.uid !== uid : !Array.isArray(response)) throw new Error("Некорректный ответ правил");
          results.rules = (uid ? [response] : response).map(normalizeRule);
        } else if (name === "states") results.states = stateRules(response);
        else {
          if (!Array.isArray(response)) throw new Error("Некорректный ответ экземпляров алертов");
          results.instances = response.map(normalizeAlert);
        }
        readStatus[name] = { ok: true };
      } catch (reason) {
        if (options.signal && options.signal.aborted) throw reason;
        const status = Number(reason && reason.status);
        readStatus[name] = { ok: false, status: status || undefined, error: status === 403 ? "Нет права чтения" : status === 404 ? "Не найдено или API недоступен" : String(reason && reason.message || "Ошибка чтения Alerting API").slice(0, 300) };
      }
    }));
    if (options.signal && options.signal.aborted) throw new DOMException("Aborted", "AbortError");
    const states = results.states || [];
    const rules = (results.rules || states).filter(rule => !uid || rule.uid === uid).map(rule => {
      const state = states.find(item => item.uid === rule.uid);
      return state ? Object.assign({}, rule, { state: state.state, health: state.health, lastError: state.lastError, lastEvaluation: state.lastEvaluation, group: state.group, interval: state.interval }) : rule;
    });
    const instances = (results.instances || []).filter(alert => !uid || alert.ruleUid === uid);
    const unmatchedInstances = uid ? (results.instances || []).filter(alert => !alert.ruleUid).length : 0;
    const summary = readStatus.instances.ok ? summarizeAlerts(instances, now) : undefined;
    const starts = instances.map(alert => Date.parse(alert.startsAt)).filter(at => Number.isFinite(at) && at > 0 && at <= now);
    const rule = uid ? rules.find(item => item.uid === uid) : undefined;
    return {
      mode: uid ? "rule" : "overview", ruleUid: uid, rule,
      rules: uid ? undefined : rules.slice(0, 100), totalRules: rules.length,
      instances: instances.slice(0, 50), totalInstances: readStatus.instances.ok ? instances.length : undefined,
      unmatchedInstances,
      truncated: rules.length > 100 || instances.length > 50,
      summary, readStatus, loadedAt: new Date(now).toISOString(),
      linkedPanel: linkedPanel(rule || instances[0]),
      timeRange: { from: Math.max(now - 24 * 3600000, starts.length ? starts.reduce((oldest, at) => Math.min(oldest, at), now) - 30 * 60000 : now - 3600000), to: now },
    };
  }

  function rulePanels(rule, resolveDatasource) {
    if (!rule) return [];
    const targets = (rule.data || []).filter(query => query.datasourceUid && query.datasourceUid !== "__expr__" && query.datasourceUid !== "-100").map(query => {
      const source = resolveDatasource(query.datasourceUid);
      return Object.assign({}, query.model, { refId: query.refId, datasource: { uid: query.datasourceUid, type: source && source.type }, alertRelativeTimeRange: query.relativeTimeRange });
    });
    return targets.length ? [{ id: 1, title: rule.title || rule.uid, type: "alert-query", targets }] : [];
  }

  const triagePrompt = "Разбери выбранный алерт: что проверяет правило, состояние и экземпляры, когда началось срабатывание, какие факты доступны, гипотезы и следующие проверки. Отделяй условие от причины, а факт срабатывания от доставки уведомления. Если данные запросов ещё не получены, явно укажи это. Не изменяй правила и не создавай silence.";
  const overviewPrompt = "Дай короткую сводку активных экземпляров алертов по service/severity: количество, самые старые, что проверить первым. Отдельно укажи подавленные экземпляры и ограничения доступа/выборки. Не выдавай отсутствие доступа за отсутствие алертов. Не делай выводов об истории или доставке уведомлений без фактов.";

  return { ruleUid, normalizeRule, stateRules, normalizeAlert, summarizeAlerts, linkedPanel, readContext, rulePanels, triagePrompt, overviewPrompt };
});
