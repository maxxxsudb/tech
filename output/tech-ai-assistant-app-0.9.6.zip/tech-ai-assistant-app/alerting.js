(function (factory) {
  if (typeof define === "function") define([], factory);
  else if (typeof module === "object" && module.exports) module.exports = factory();
})(function () {
  "use strict";

  function ruleUid(pathname) {
    const match = /\/alerting\/grafana\/([^/]+)\/(?:view|edit)(?:\/|$)/.exec(pathname || "");
    if (!match) return undefined;
    try { return decodeURIComponent(match[1]); } catch (_) { return undefined; }
  }

  function normalizeRule(value) {
    const source = value.grafana_alert || value;
    return {
      uid: source.uid || value.uid,
      title: source.title || value.name || value.alert,
      folderUID: source.folderUID || source.namespace_uid,
      ruleGroup: source.ruleGroup || source.rule_group,
      condition: source.condition,
      for: value.for ?? source.for,
      keepFiringFor: source.keep_firing_for ?? source.keepFiringFor,
      missingSeriesEvalsToResolve: source.missingSeriesEvalsToResolve,
      notificationSettings: source.notification_settings || source.notificationSettings,
      record: source.record,
      noDataState: source.noDataState || source.no_data_state,
      execErrState: source.execErrState || source.exec_err_state,
      isPaused: source.isPaused ?? source.is_paused,
      provenance: source.provenance,
      labels: value.labels || source.labels || {},
      annotations: value.annotations || source.annotations || {},
      state: value.state,
      health: value.health,
      lastError: value.lastError,
      lastEvaluation: value.lastEvaluation,
      data: Array.isArray(source.data) ? source.data.map(query => ({
        refId: query.refId, datasourceUid: query.datasourceUid,
        relativeTimeRange: query.relativeTimeRange, queryType: query.queryType, model: query.model,
      })) : [],
    };
  }

  function stateRules(response) {
    if (!response || response.status !== "success" || !response.data || !Array.isArray(response.data.groups)) throw new Error("Некорректный ответ состояния правил");
    return response.data.groups.flatMap(group => (group.rules || []).map(value => Object.assign(normalizeRule(value), { group: group.name, interval: group.interval })));
  }

  function alertRuleUid(value) {
    const labels = value.labels || {};
    if (labels.__alert_rule_uid__) return labels.__alert_rule_uid__;
    if (labels.__rule_uid__) return labels.__rule_uid__;
    try { return ruleUid(new URL(value.generatorURL, "http://grafana.invalid").pathname); } catch (_) { return undefined; }
  }

  function normalizeAlert(value) {
    return {
      ruleUid: alertRuleUid(value), fingerprint: value.fingerprint,
      labels: value.labels || {}, annotations: value.annotations || {},
      startsAt: value.startsAt, endsAt: value.endsAt, updatedAt: value.updatedAt,
      status: value.status && { state: value.status.state, silencedBy: value.status.silencedBy, inhibitedBy: value.status.inhibitedBy },
    };
  }

  function summarizeAlerts(alerts, now) {
    const groups = new Map();
    for (const alert of alerts) {
      const service = alert.labels.service || "не указан";
      const severity = alert.labels.severity || "не указана";
      const key = JSON.stringify([service, severity]);
      const group = groups.get(key) || { service, severity, instances: 0, suppressed: 0, oldestAt: undefined, ruleUids: [] };
      group.instances++;
      if (alert.status && alert.status.state === "suppressed") group.suppressed++;
      const start = Date.parse(alert.startsAt);
      if (Number.isFinite(start) && start > 0 && start <= now && (!group.oldestAt || start < Date.parse(group.oldestAt))) group.oldestAt = alert.startsAt;
      if (alert.ruleUid && !group.ruleUids.includes(alert.ruleUid)) group.ruleUids.push(alert.ruleUid);
      groups.set(key, group);
    }
    return { instances: alerts.length, groups: Array.from(groups.values()).sort((a, b) => b.instances - a.instances) };
  }

  function linkedPanel(rule) {
    const annotations = rule && rule.annotations || {};
    const id = Number(annotations.__panelId__ || annotations.panelId);
    return {
      dashboardUid: annotations.__dashboardUid__ || annotations.dashboardUid,
      panelId: Number.isInteger(id) && id > 0 ? id : undefined,
    };
  }

  async function readContext(request, options) {
    options = options || {};
    const now = options.now || Date.now(), uid = options.uid;
    const endpoints = [
      ["rules", "/api/v1/provisioning/alert-rules" + (uid ? "/" + encodeURIComponent(uid) : "")],
      ["states", "/api/prometheus/grafana/api/v1/rules"],
      ["instances", "/api/alertmanager/grafana/api/v2/alerts"],
    ];
    const readStatus = {}, results = {};
    await Promise.all(endpoints.map(async ([name, path]) => {
      try {
        const response = await request(path, { signal: options.signal, timeoutMs: 10000 });
        if (name === "rules") {
          if (uid ? !response || typeof response !== "object" || Array.isArray(response) || response.uid !== uid : !Array.isArray(response)) throw new Error("Некорректный ответ правил");
          results.rules = (uid ? [response] : response).map(normalizeRule);
        } else if (name === "states") results.states = stateRules(response);
        else {
          if (!Array.isArray(response)) throw new Error("Некорректный ответ экземпляров алертов");
          results.instances = response.map(normalizeAlert);
        }
        readStatus[name] = { ok: true };
      } catch (reason) {
        if (options.signal && options.signal.aborted) throw reason;
        const status = Number(reason && reason.status);
        readStatus[name] = { ok: false, status: status || undefined, error: status === 403 ? "Нет права чтения" : status === 404 ? "Не найдено или API недоступен" : String(reason && reason.message || "Ошибка чтения Alerting API").slice(0, 300) };
      }
    }));
    if (options.signal && options.signal.aborted) throw new DOMException("Aborted", "AbortError");
    const states = results.states || [];
    const rules = (results.rules || states).filter(rule => !uid || rule.uid === uid).map(rule => {
      const state = states.find(item => item.uid === rule.uid);
      return state ? Object.assign({}, rule, { state: state.state, health: state.health, lastError: state.lastError, lastEvaluation: state.lastEvaluation, group: state.group, interval: state.interval }) : rule;
    });
    const instances = (results.instances || []).filter(alert => !uid || alert.ruleUid === uid);
    const unmatchedInstances = uid ? (results.instances || []).filter(alert => !alert.ruleUid).length : 0;
    const summary = readStatus.instances.ok ? summarizeAlerts(instances, now) : undefined;
    const starts = instances.map(alert => Date.parse(alert.startsAt)).filter(at => Number.isFinite(at) && at > 0 && at <= now);
    const rule = uid ? rules.find(item => item.uid === uid) : undefined;
    return {
      mode: uid ? "rule" : "overview", ruleUid: uid, rule,
      rules: uid ? undefined : rules.slice(0, 100), totalRules: rules.length,
      instances: instances.slice(0, 50), totalInstances: readStatus.instances.ok ? instances.length : undefined,
      unmatchedInstances,
      truncated: rules.length > 100 || instances.length > 50,
      summary, readStatus, loadedAt: new Date(now).toISOString(),
      linkedPanel: linkedPanel(rule || instances[0]),
      timeRange: { from: Math.max(now - 24 * 3600000, starts.length ? starts.reduce((oldest, at) => Math.min(oldest, at), now) - 30 * 60000 : now - 3600000), to: now },
    };
  }

  function rulePanels(rule, resolveDatasource) {
    if (!rule) return [];
    const targets = (rule.data || []).filter(query => query.datasourceUid && query.datasourceUid !== "__expr__" && query.datasourceUid !== "-100").map(query => {
      const source = resolveDatasource(query.datasourceUid);
      return Object.assign({}, query.model, { refId: query.refId, datasource: { uid: query.datasourceUid, type: source && source.type }, alertRelativeTimeRange: query.relativeTimeRange });
    });
    return targets.length ? [{ id: 1, title: rule.title || rule.uid, type: "alert-query", targets }] : [];
  }

  function durationSeconds(value) {
    if (typeof value === "number") return Number.isFinite(value) && value >= 0 ? value : undefined;
    if (!/^(?:\d+(?:\.\d+)?(?:ms|s|m|h|d|w))+$/.test(String(value || ""))) return undefined;
    return Array.from(value.matchAll(/(\d+(?:\.\d+)?)(ms|s|m|h|d|w)/g)).reduce((sum, part) => sum + Number(part[1]) * ({ ms: .001, s: 1, m: 60, h: 3600, d: 86400, w: 604800 }[part[2]]), 0);
  }

  function timingActive(timing, now) {
    const weekdays = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    const months = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
    try {
      let unknown = false;
      for (const interval of timing.time_intervals || []) {
        const fields = Object.fromEntries(new Intl.DateTimeFormat("en-GB", { timeZone: interval.location || "UTC", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", weekday: "long", hourCycle: "h23" }).formatToParts(new Date(now)).map(part => [part.type, part.value]));
        const year = Number(fields.year), month = Number(fields.month), day = Number(fields.day), lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
        const ranges = (values, actual, names, negative) => !values?.length || values.some(value => {
          const parts = String(value).toLowerCase().split(":");
          if (parts.length > 2) throw Error("Неизвестный диапазон времени");
          const parse = text => { let n = names ? names === months && /^\d+$/.test(text) ? Number(text) - 1 : names.indexOf(text) : Number(text); if (names && (n < 0 || n >= names.length) || !Number.isInteger(n)) throw Error("Неизвестное значение времени"); if (negative && n < 0) n = lastDay + 1 + n; return n; };
          const start = parse(parts[0]), end = parse(parts[1] ?? parts[0]);
          return actual >= start && actual <= end;
        });
        const minute = Number(fields.hour) * 60 + Number(fields.minute);
        const time = text => { if (!/^\d\d:\d\d$/.test(text)) throw Error("Неизвестное время"); const [h, m] = text.split(":").map(Number); if (h > 24 || m > 59 || h === 24 && m) throw Error("Некорректное время"); return h * 60 + m; };
        const active = (!interval.times?.length || interval.times.some(range => minute >= time(range.start_time) && minute < time(range.end_time))) && ranges(interval.weekdays, weekdays.indexOf(fields.weekday.toLowerCase()), weekdays) && ranges(interval.months, month - 1, months) && ranges(interval.days_of_month, day, undefined, true) && ranges(interval.years, year);
        if (Object.keys(interval).some(key => !["location", "times", "weekdays", "months", "days_of_month", "years"].includes(key))) unknown = true;
        else if (active) return true;
      }
      return unknown ? undefined : false;
    } catch (_) { return undefined; }
  }

  function routePreview(policy, labels, contacts, timings, now, unknownLabels) {
    const routes = [], limitations = [];
    const unknown = text => { if (!limitations.includes(text)) limitations.push(text); return undefined; };
    function matches(route) {
      const textual = [];
      for (const text of route.matchers || []) {
        const match = /^\s*([a-zA-Z_][a-zA-Z_0-9]*)\s*(=~|!~|!=|=)\s*("(?:\\.|[^"\\])*"|[a-zA-Z0-9_.:-]+)\s*$/.exec(text);
        if (!match) return unknown("Текстовый matcher требует проверки в Grafana");
        try { textual.push([match[1], match[2], match[3].startsWith('"') ? JSON.parse(match[3]) : match[3]]); } catch (_) { return unknown("Неизвестное экранирование matcher"); }
      }
      const matchers = (route.object_matchers || []).concat(textual, Object.entries(route.match || {}).map(([name, value]) => [name, "=", value]), Object.entries(route.match_re || {}).map(([name, value]) => [name, "=~", value]));
      let uncertain = false;
      for (const [name, operator, value] of matchers) {
        if (unknownLabels?.includes(name)) { uncertain = true; continue; }
        const actual = String(labels[name] ?? ""); let equal;
        if (operator === "=" || operator === "!=") equal = actual === String(value);
        else if (operator === "=~" || operator === "!~") {
          if (String(value).length > 200 || actual.length > 512 || /[(){}]|\\[1-9]|\\[pP]/.test(value)) { uncertain = true; continue; }
          try { const match = new RegExp("^(?:" + value + ")$").exec(actual); equal = !!match && match[0].length === actual.length; } catch (_) { uncertain = true; continue; }
        } else { uncertain = true; continue; }
        if (operator === "!=" || operator === "!~") equal = !equal;
        if (!equal) return false;
      }
      return uncertain ? unknown("Не удалось точно сопоставить matcher или labels") : true;
    }
    function visit(route, parent, path, depth) {
      if (depth > 20) { unknown("Слишком глубокое дерево policies"); return; }
      const effective = Object.assign({}, parent, route);
      let childMatched = false;
      for (const [i, child] of (route.routes || []).entries()) {
        const match = matches(child);
        if (match === undefined) { childMatched = true; break; }
        if (!match) continue;
        childMatched = true; visit(child, effective, path + "." + i, depth + 1);
        if (!child.continue) break;
      }
      if (childMatched) return;
      const named = names => (names || []).map(name => {
        const timing = timings?.find(item => item.name === name);
        return { name, active: timing ? timingActive(timing, now) : undefined };
      });
      const mute = named(effective.mute_time_intervals), active = named(effective.active_time_intervals);
      const muted = mute.some(item => item.active === true) || active.length > 0 && active.every(item => item.active === false);
      const timingUnknown = mute.some(item => item.active === undefined) || active.some(item => item.active === undefined);
      if (timingUnknown) unknown("Часть временных интервалов недоступна или не поддерживается");
      const receiver = effective.receiver;
      routes.push({ path, receiver, contactExists: contacts ? contacts.some(item => item.name === receiver) : undefined, muted: timingUnknown && !muted ? undefined : muted, mute, active });
    }
    if (!policy) return { status: "unavailable", routes, limitations: ["Notification policies недоступны"], deliveryVerified: false };
    if (!contacts) unknown("Contact points недоступны");
    visit(policy, {}, "root", 0);
    return { status: limitations.length ? "partial" : "known", routes, limitations, deliveryVerified: false };
  }

  function auditRules(rules, resources, now) {
    resources = resources || {}; now = now || Date.now();
    const stable = value => value && typeof value === "object" ? Array.isArray(value) ? value.map(stable) : Object.fromEntries(Object.keys(value).sort().map(key => [key, stable(value[key])])) : value;
    const fingerprints = new Map();
    for (const rule of rules) {
      const key = JSON.stringify(stable({ condition: rule.condition, data: rule.data, labels: rule.labels }));
      const values = fingerprints.get(key) || []; values.push(rule.uid); fingerprints.set(key, values);
    }
    const results = rules.map(rule => {
      const issues = [];
      const issue = (code, severity, message, evidence, suggestion) => issues.push({ code, severity, message, evidence, suggestion });
      if (rule.record) return { uid: rule.uid, title: rule.title, score: null, issues: [{ code: "recording_rule", severity: "info", message: "Recording rule: alert-проверки неприменимы", evidence: { record: rule.record } }] };
      const interval = durationSeconds(rule.interval), pending = durationSeconds(rule.for);
      if (pending === undefined || pending === 0 || interval && pending < interval * 2) issue("pending", "warning", "Проверьте выдержку перед срабатыванием", { for: rule.for ?? null, intervalSeconds: interval ?? null }, "Выберите for под скорость реакции и допустимый шум; короткий for может быть намеренным.");
      for (const [field, state] of [["noDataState", rule.noDataState], ["execErrState", rule.execErrState]]) {
        if (["OK", "Normal"].includes(state)) issue(field, "warning", "Отсутствие данных или ошибка переводит правило в Normal", { [field]: state }, "Проверьте, допустимо ли скрывать этот отказ для данного правила.");
        else if (!state) issue(field, "info", "Политика состояния не получена", { [field]: null });
      }
      for (const name of ["summary", "description", "runbook_url"]) if (!String(rule.annotations?.[name] || "").trim()) issue("annotation_" + name, "warning", "Не заполнено " + name, { annotation: name, value: rule.annotations?.[name] ?? null }, "Добавьте понятное описание или ссылку для дежурного.");
      for (const name of ["team", "service", "severity"]) if (!String(rule.labels?.[name] || "").trim()) issue("label_" + name, "warning", "Не указан label " + name, { label: name, value: rule.labels?.[name] ?? null }, "Укажите владельца, сервис и важность для маршрутизации.");
      const link = linkedPanel(rule);
      if (!link.dashboardUid || !link.panelId) issue("panel_link", "warning", "Нет полной ссылки на dashboard/panel", link, "Свяжите правило с диагностической панелью.");
      if (rule.isPaused) issue("paused", "info", "Правило приостановлено", { isPaused: true });
      if (rule.lastError || rule.health === "error") issue("evaluation_error", "error", "Grafana сообщает ошибку evaluation", { health: rule.health, lastError: rule.lastError, lastEvaluation: rule.lastEvaluation }, "Исправьте запрос по фактической ошибке; проверьте datasource и схему.");
      if (rule.provenance) issue("provenance", "info", "Правило управляется provisioning", { provenance: rule.provenance }, "Изменения готовьте для исходной конфигурации.");
      if (!interval) issue("interval_unknown", "info", "Интервал evaluation не получен", { ruleGroup: rule.ruleGroup, interval: rule.interval ?? null });
      for (const query of rule.data || []) {
        if (["__expr__", "-100"].includes(query.datasourceUid)) continue;
        const range = Number(query.relativeTimeRange?.from) - Number(query.relativeTimeRange?.to || 0);
        if (interval && range > 0 && range < interval) issue("query_range", "warning", "Окно запроса короче интервала оценки", { refId: query.refId, rangeSeconds: range, intervalSeconds: interval });
        const sql = query.model?.rawSql;
        if (sql && /\$(?!__)[a-zA-Z_][a-zA-Z_0-9]*|\$\{(?!__)[^}]+\}/.test(sql)) issue("sql_variables", "error", "В SQL правила есть переменные дашборда", { refId: query.refId, variables: sql.match(/\$(?!__)[a-zA-Z_][a-zA-Z_0-9]*|\$\{(?!__)[^}]+\}/g) }, "Alert evaluation не использует переменные дашборда; задайте явные условия.");
      }
      const duplicates = fingerprints.get(JSON.stringify(stable({ condition: rule.condition, data: rule.data, labels: rule.labels }))).filter(uid => uid !== rule.uid);
      if (duplicates.length) issue("duplicate", "warning", "Совпадают запросы, condition и labels", { otherRuleUids: duplicates }, "Проверьте необходимость дублей; разные for и окна работы могут быть намеренными.");
      const folder = resources.folders?.find(item => item.uid === rule.folderUID);
      const labels = Object.assign({ alertname: rule.title }, folder ? { grafana_folder: folder.title } : {}, rule.labels);
      const direct = rule.notificationSettings?.receiver;
      const unknownLabels = Object.keys(labels).filter(name => /\{\{/.test(String(labels[name])));
      if (!folder && !labels.grafana_folder) unknownLabels.push("grafana_folder");
      const collectUnknown = (route, depth) => {
        if (!route || depth > 20) return;
        for (const name of (route.object_matchers || []).map(item => item[0]).concat((route.matchers || []).map(text => /^\s*([a-zA-Z_][a-zA-Z_0-9]*)/.exec(text)?.[1]).filter(Boolean), Object.keys(route.match || {}), Object.keys(route.match_re || {}))) if (!Object.hasOwn(labels, name) && !unknownLabels.includes(name)) unknownLabels.push(name);
        for (const child of route.routes || []) collectUnknown(child, depth + 1);
      };
      collectUnknown(resources.policies, 0);
      const routing = routePreview(direct ? Object.assign({}, rule.notificationSettings, { receiver: direct }) : resources.policies, labels, resources.contacts, resources.timings, now, unknownLabels);
      if (routing.status !== "known") issue("routing_unknown", "info", "Маршрут проверен не полностью", { status: routing.status, limitations: routing.limitations });
      for (const route of routing.routes) if (route.contactExists === false || !route.receiver) issue("receiver_missing", "error", "Получатель маршрута не найден", route, "Проверьте notification policies и contact point в Grafana.");
      const score = Math.max(0, 100 - issues.reduce((sum, item) => sum + (item.severity === "error" ? 20 : item.severity === "warning" ? 5 : 0), 0));
      return { uid: rule.uid, title: rule.title, folderUID: rule.folderUID, ruleGroup: rule.ruleGroup, score, issues, routing };
    });
    return { loadedAt: new Date(now).toISOString(), totalRules: rules.length, rules: results, scoreMethod: "100 − 20 за error − 5 за warning; info не снижает оценку. Эвристический checklist, не вероятность надёжности.", deliveryVerified: false };
  }

  async function readAudit(request, options) {
    options = options || {};
    const resources = {}, readStatus = {};
    const endpoints = [["rules", "/api/v1/provisioning/alert-rules"], ["states", "/api/prometheus/grafana/api/v1/rules"], ["policies", "/api/v1/provisioning/policies"], ["contacts", "/api/v1/provisioning/contact-points"], ["timings", "/api/v1/provisioning/mute-timings"], ["folders", "/api/folders?limit=1000"]];
    await Promise.all(endpoints.map(async ([name, endpoint]) => {
      try {
        const response = await request(endpoint, { signal: options.signal, timeoutMs: 10000 });
        if (name === "policies") { if (!response || typeof response.receiver !== "string") throw Error("Некорректный ответ policies"); resources[name] = response; }
        else if (name === "states") resources[name] = stateRules(response);
        else {
          if (!Array.isArray(response)) throw Error("Некорректный ответ " + name);
          resources[name] = name === "contacts" ? response.map(item => ({ name: item.name, type: item.type })) : name === "rules" ? response.map(normalizeRule) : response;
        }
        readStatus[name] = { ok: true };
      } catch (reason) {
        if (options.signal?.aborted) throw reason;
        readStatus[name] = { ok: false, status: reason.status, error: reason.status === 403 ? "Нет права чтения" : String(reason.message || "Ошибка Alerting API").slice(0, 200) };
      }
    }));
    if (options.signal?.aborted) throw new DOMException("Aborted", "AbortError");
    if (!readStatus.rules.ok) return { loadedAt: new Date().toISOString(), unavailable: true, rules: [], readStatus };
    const states = new Map((resources.states || []).map(rule => [rule.uid, rule]));
    const rules = resources.rules.map(rule => { const state = states.get(rule.uid); return Object.assign({}, rule, { interval: state?.interval, health: state?.health, lastError: state?.lastError, lastEvaluation: state?.lastEvaluation }); });
    return Object.assign(auditRules(rules, resources, options.now), { readStatus });
  }

  function auditMarkdown(report) {
    const lines = ["# Аудит правил Grafana", "", "Снимок: " + report.loadedAt, "", report.unavailable ? "Правила недоступны; это не пустой список." : report.scoreMethod, "", "Доставка уведомлений не проверялась."];
    const plain = value => String(value ?? "").replace(/[\r\n]/g, " ");
    for (const [name, status] of Object.entries(report.readStatus || {})) if (!status.ok) lines.push("", name + ": " + plain(status.error));
    for (const rule of report.rules || []) {
      lines.push("", "## " + plain(rule.title) + " (" + plain(rule.uid) + ")", "", "Checklist: " + (rule.score ?? "н/д") + "/100");
      for (const issue of rule.issues) lines.push("", "- [" + issue.severity + "] " + plain(issue.message) + "; evidence: " + JSON.stringify(issue.evidence) + (issue.suggestion ? "; " + issue.suggestion : ""));
      if (rule.routing) lines.push("", "Маршрут: " + JSON.stringify(rule.routing));
    }
    return lines.join("\n");
  }

  const triagePrompt = "Разбери выбранный алерт: что проверяет правило, состояние и экземпляры, когда началось срабатывание, какие факты доступны, гипотезы и следующие проверки. Отделяй условие от причины, а факт срабатывания от доставки уведомления. Если данные запросов ещё не получены, явно укажи это. Не изменяй правила и не создавай silence.";
  const overviewPrompt = "Дай короткую сводку активных экземпляров алертов по service/severity: количество, самые старые, что проверить первым. Отдельно укажи подавленные экземпляры и ограничения доступа/выборки. Не выдавай отсутствие доступа за отсутствие алертов. Не делай выводов об истории или доставке уведомлений без фактов.";

  return { ruleUid, normalizeRule, stateRules, normalizeAlert, summarizeAlerts, linkedPanel, readContext, rulePanels, durationSeconds, timingActive, routePreview, auditRules, readAudit, auditMarkdown, triagePrompt, overviewPrompt };
});
