define(["@grafana/data"], function (grafanaData) {
  const style = document.createElement("style");
  style.textContent = `
    body.tech-dashboard-print nav,
    body.tech-dashboard-print header,
    body.tech-dashboard-print a[href="#pageContent"],
    body.tech-dashboard-print [data-testid="data-testid navigation mega-menu"],
    body.tech-dashboard-print [data-testid*="sidemenu"],
    body.tech-dashboard-print [data-testid*="dashboard controls"],
    body.tech-dashboard-print [data-testid*="dashboard-toolbar"],
    body.tech-dashboard-print button[aria-label^="Menu for panel"],
    body.tech-dashboard-print.tech-dashboard-print-hide-panel-titles [data-testid="data-testid header-container"],
    body.tech-dashboard-print [data-testid*="new export button"],
    body.tech-dashboard-print .tech-dashboard-print-controls {
      display: none !important;
    }

    body.tech-dashboard-print #pageContent {
      padding-left: 0 !important;
    }

    body.tech-dashboard-print .main-view > div {
      padding-top: 0 !important;
    }

    @media print {
      @page { size: auto; margin: 8mm; }
      html, body, #reactRoot, .main-view, .main-view > div {
        height: auto !important;
        max-height: none !important;
        overflow: visible !important;
      }
      body.tech-dashboard-print {
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
      }
      body.tech-dashboard-print [class*="scrollbar"],
      body.tech-dashboard-print [class*="scroll-container"] {
        max-height: none !important;
        overflow: visible !important;
      }
      body.tech-dashboard-print .react-grid-item,
      body.tech-dashboard-print section[data-testid^="data-testid Panel header"],
      body.tech-dashboard-print section[data-testid^="data-testid Panel header"] > div {
        break-inside: avoid-page !important;
        page-break-inside: avoid !important;
      }

      body.tech-dashboard-print canvas,
      body.tech-dashboard-print svg {
        break-inside: avoid-page !important;
        page-break-inside: avoid !important;
      }
    }
  `;
  document.head.appendChild(style);

  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  let originalScrollY = 0;
  let printing = false;
  let hidePanelTitles = true;
  let shortcut = "Ctrl+Alt+Shift+P";
  const settingsReady = fetch('/api/plugins/tech-dashboard-print-app/settings')
    .then((response) => response.ok ? response.json() : null)
    .then((settings) => {
      if (typeof settings?.jsonData?.hidePanelTitles === 'boolean') {
        hidePanelTitles = settings.jsonData.hidePanelTitles;
      }
      if (typeof settings?.jsonData?.shortcut === 'string' && settings.jsonData.shortcut.trim()) {
        shortcut = settings.jsonData.shortcut.trim();
      }
    })
    .catch(() => {});

  async function printDashboard() {
    if (printing) return;
    printing = true;
    await settingsReady;
    originalScrollY = window.scrollY;
    const step = Math.max(400, Math.floor(window.innerHeight * 0.8));
    const height = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
    document.body.classList.add("tech-dashboard-print");
    document.body.classList.toggle("tech-dashboard-print-hide-panel-titles", hidePanelTitles);

    for (let y = 0; y < height; y += step) {
      window.scrollTo(0, y);
      await delay(120);
    }

    window.scrollTo(0, originalScrollY);
    await delay(300);
    window.print();
  }

  function restoreDashboard() {
    document.body.classList.remove("tech-dashboard-print");
    document.body.classList.remove("tech-dashboard-print-hide-panel-titles");
    window.scrollTo(0, originalScrollY);
    printing = false;
  }

  function matchesShortcut(event) {
    const tokens = shortcut.split("+").map((token) => token.trim().toUpperCase()).filter(Boolean);
    const key = tokens.find((token) => !["CTRL", "CONTROL", "ALT", "SHIFT", "META", "CMD"].includes(token));
    if (!key) return false;
    if (event.ctrlKey !== (tokens.includes("CTRL") || tokens.includes("CONTROL"))) return false;
    if (event.altKey !== tokens.includes("ALT")) return false;
    if (event.shiftKey !== tokens.includes("SHIFT")) return false;
    if (event.metaKey !== (tokens.includes("META") || tokens.includes("CMD"))) return false;

    const eventKey = String(event.key || "").toUpperCase();
    const eventCode = String(event.code || "").toUpperCase();
    return eventKey === key || eventCode === key || eventCode === `KEY${key}` || eventCode === `DIGIT${key}`;
  }

  document.addEventListener("keydown", (event) => {
    if (event.repeat || !matchesShortcut(event)) return;
    if (!window.location.pathname.startsWith("/d/")) return;
    if (event.target instanceof Element && event.target.closest("input, textarea, select, [contenteditable='true']")) return;

    event.preventDefault();
    event.stopPropagation();
    printDashboard();
  }, true);
  window.addEventListener("tech-dashboard-print", printDashboard);
  window.addEventListener("afterprint", restoreDashboard);

  return { plugin: new grafanaData.AppPlugin() };
});
