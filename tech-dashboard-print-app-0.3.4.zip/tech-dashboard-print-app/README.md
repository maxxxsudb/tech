# Dashboard Print

Требуется Grafana 13.0.2 или новее.

Разрешите неподписанный плагин:

```yaml
GF_PLUGINS_ALLOW_LOADING_UNSIGNED_PLUGINS: tech-dashboard-print-app
```

Без настройки работают `Ctrl+Alt+p` и `Ctrl+Alt+Shift+P`. Диагностические сообщения выключены.

Необязательная настройка через файл `/etc/grafana/provisioning/plugins/dashboard-print.yaml`:

```yaml
apiVersion: 1

apps:
  - type: tech-dashboard-print-app
    org_id: 1
    disabled: false
    jsonData:
      hidePanelTitles: true
      shortcuts:
        - Ctrl+Alt+P
        - Ctrl+Alt+Shift+P
      debug: false
```

Для диагностики временно установите `debug: true`: плагин покажет загрузку, фактически полученную клавишу и причину отказа.

Путь Grafana может содержать subpath, например `/crf/dashboard`. Дашборд определяется по маршруту и DOM панелей.
