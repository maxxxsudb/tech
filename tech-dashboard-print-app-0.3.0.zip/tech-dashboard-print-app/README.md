# Dashboard Print

Требуется Grafana 13.0.2 или новее.

Разрешите неподписанный плагин:

```yaml
GF_PLUGINS_ALLOW_LOADING_UNSIGNED_PLUGINS: tech-dashboard-print-app
```

Настройки provisioning:

```yaml
apiVersion: 1

apps:
  - type: tech-dashboard-print-app
    org_id: 1
    disabled: false
    jsonData:
      hidePanelTitles: true
      shortcuts:
        - F8
        - F9
        - Ctrl+Alt+P
      debug: true
```

`debug: true` показывает загрузку плагина, фактически полученную клавишу и причину отказа. После проверки переключите на `false`.

Путь Grafana может содержать subpath, например `/crf/dashboard`. Дашборд определяется по маршруту и DOM панелей.
