define(["@grafana/data", "@grafana/runtime"], function (grafanaData, grafanaRuntime) {
  const style = document.createElement("style");
  style.textContent = `
    body.tech-dashboard-print nav,
    body.tech-dashboard-print header,
    body.tech-dashboard-print a[href="#pageContent"],
    body.tech-dashboard-print [data-testid="data-testid navigation mega-menu"],
    body.tech-dashboard-print [data-testid*="sidemenu"],
    body.tech-dashboard-print [data-testid*="dashboard controls"],
    body.tech-dashboard-print [data-testid*="dashboard-toolbar"],
    body.tech-dashboard-print button[aria-label^="Menu for panel"],
    body.tech-dashboard-print.tech-dashboard-print-hide-panel-titles [data-testid="data-testid header-container"],
    body.tech-dashboard-print [data-testid*="new export button"],
    body.tech-dashboard-print .tech-dashboard-print-controls,
    body.tech-dashboard-print .tech-dashboard-print-status {
      display: none !important;
    }

    body.tech-dashboard-print #pageContent {
      padding-left: 0 !important;
    }

    body.tech-dashboard-print .main-view > div {
      padding-top: 0 !important;
    }

    @media print {
      @page { size: auto; margin: 8mm; }
      html, body, #reactRoot, .main-view, .main-view > div {
        height: auto !important;
        max-height: none !important;
        overflow: visible !important;
      }
      body.tech-dashboard-print {
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
      }
      body.tech-dashboard-print [class*="scrollbar"],
      body.tech-dashboard-print [class*="scroll-container"] {
        max-height: none !important;
        overflow: visible !important;
      }
      body.tech-dashboard-print .react-grid-item,
      body.tech-dashboard-print section[data-testid^="data-testid Panel header"],
      body.tech-dashboard-print section[data-testid^="data-testid Panel header"] > div {
        break-inside: avoid-page !important;
        page-break-inside: avoid !important;
      }

      body.tech-dashboard-print canvas,
      body.tech-dashboard-print svg {
        break-inside: avoid-page !important;
        page-break-inside: avoid !important;
      }
    }
  `;
  document.head.appendChild(style);

  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  let originalScrollY = 0;
  let printing = false;
  let hidePanelTitles = true;
  let shortcuts = ["Ctrl+Alt+Shift+P"];
  let debug = true;

  function showStatus(message, kind = "info") {
    if (!debug) return;
    let status = document.querySelector(".tech-dashboard-print-status");
    if (!status) {
      status = document.createElement("div");
      status.className = "tech-dashboard-print-status";
      Object.assign(status.style, {
        position: "fixed",
        top: "16px",
        right: "16px",
        zIndex: "2147483647",
        maxWidth: "520px",
        padding: "12px 16px",
        borderRadius: "6px",
        color: "#fff",
        font: "14px/1.4 sans-serif",
        boxShadow: "0 4px 16px rgba(0,0,0,.45)",
        whiteSpace: "pre-wrap",
      });
      document.body.appendChild(status);
    }
    status.style.background = kind === "error" ? "#c62828" : kind === "success" ? "#2e7d32" : "#1f60c4";
    status.textContent = `Dashboard Print: ${message}`;
    clearTimeout(status._hideTimer);
    status._hideTimer = setTimeout(() => status.remove(), 7000);
  }

  const settingsReady = grafanaRuntime.getBackendSrv()
    .get('/api/plugins/tech-dashboard-print-app/settings')
    .then((settings) => {
      if (typeof settings?.jsonData?.hidePanelTitles === 'boolean') {
        hidePanelTitles = settings.jsonData.hidePanelTitles;
      }
      if (Array.isArray(settings?.jsonData?.shortcuts)) {
        const configured = settings.jsonData.shortcuts.filter((value) => typeof value === "string" && value.trim()).map((value) => value.trim());
        if (configured.length) shortcuts = configured;
      } else if (typeof settings?.jsonData?.shortcut === 'string' && settings.jsonData.shortcut.trim()) {
        shortcuts = [settings.jsonData.shortcut.trim()];
      }
      if (typeof settings?.jsonData?.debug === 'boolean') {
        debug = settings.jsonData.debug;
      }
    })
    .catch((error) => showStatus(`не удалось прочитать настройки: ${error.message}`, "error"));

  async function printDashboard() {
    if (printing) return;
    printing = true;
    await settingsReady;
    originalScrollY = window.scrollY;
    const step = Math.max(400, Math.floor(window.innerHeight * 0.8));
    const height = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
    document.body.classList.add("tech-dashboard-print");
    document.body.classList.toggle("tech-dashboard-print-hide-panel-titles", hidePanelTitles);

    for (let y = 0; y < height; y += step) {
      window.scrollTo(0, y);
      await delay(120);
    }

    window.scrollTo(0, originalScrollY);
    await delay(300);
    window.print();
  }

  function restoreDashboard() {
    document.body.classList.remove("tech-dashboard-print");
    document.body.classList.remove("tech-dashboard-print-hide-panel-titles");
    window.scrollTo(0, originalScrollY);
    printing = false;
  }

  function matchesShortcutDefinition(event, definition) {
    const tokens = definition.split("+").map((token) => token.trim().toUpperCase()).filter(Boolean);
    const key = tokens.find((token) => !["CTRL", "CONTROL", "ALT", "SHIFT", "META", "CMD"].includes(token));
    if (!key) return false;
    if (event.ctrlKey !== (tokens.includes("CTRL") || tokens.includes("CONTROL"))) return false;
    if (event.altKey !== tokens.includes("ALT")) return false;
    if (event.shiftKey !== tokens.includes("SHIFT")) return false;
    if (event.metaKey !== (tokens.includes("META") || tokens.includes("CMD"))) return false;

    const eventKey = String(event.key || "").toUpperCase();
    const eventCode = String(event.code || "").toUpperCase();
    return eventKey === key || eventCode === key || eventCode === `KEY${key}` || eventCode === `DIGIT${key}`;
  }

  function matchesShortcut(event) {
    return shortcuts.some((definition) => matchesShortcutDefinition(event, definition));
  }

  document.addEventListener("keydown", async (event) => {
    await settingsReady;
    const received = `${event.ctrlKey ? "Ctrl+" : ""}${event.altKey ? "Alt+" : ""}${event.shiftKey ? "Shift+" : ""}${event.metaKey ? "Meta+" : ""}${event.key} (code=${event.code})`;
    if (event.repeat) {
      showStatus(`получено ${received}; отклонено: повтор клавиши`);
      return;
    }
    if (!matchesShortcut(event)) {
      showStatus(`получено ${received}; ожидается ${shortcuts.join(" / ")}`);
      return;
    }
    const dashboardFound = /(^|\/)d\//.test(window.location.pathname) || document.querySelector(
      ".react-grid-layout, [data-testid='dashboard-grid'], section[data-testid^='data-testid Panel header'], [data-testid*='panel-content']"
    );
    if (!dashboardFound) {
      showStatus(`клавиша принята, но DOM дашборда не найден; путь ${window.location.pathname}`, "error");
      return;
    }
    if (event.target instanceof Element && event.target.closest("input, textarea, select, [contenteditable='true']")) {
      showStatus("клавиша принята, но фокус находится в поле ввода", "error");
      return;
    }

    event.preventDefault();
    event.stopPropagation();
    showStatus(`получено ${received}; запускаю печать`, "success");
    printDashboard().catch((error) => {
      printing = false;
      showStatus(`ошибка: ${error.message}`, "error");
    });
  }, true);
  window.addEventListener("tech-dashboard-print", printDashboard);
  window.addEventListener("afterprint", restoreDashboard);

  settingsReady.then(() => {
    showStatus(`плагин активен; путь ${window.location.pathname}; сочетания ${shortcuts.join(" / ")}`, "success");
  });

  return { plugin: new grafanaData.AppPlugin() };
});
